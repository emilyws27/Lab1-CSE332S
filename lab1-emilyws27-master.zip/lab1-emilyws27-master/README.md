# initial_lab
Base repository for labs 1-4, initializes the repo and populates with an appropriate .gitignore file
