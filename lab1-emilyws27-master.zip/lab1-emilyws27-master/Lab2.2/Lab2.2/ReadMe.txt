Emily Sheehan, WUSTL ID: 490280
Lab 2

I ran into several errors while trying to build this program. The main error was a linker error, where I had not defined the game_pieces constructor within the GamePieces.cpp file.

Then, I had an issue where my range on my for loops were going out of bounds in the print function inside GameBoard.cpp. I fixed this by subtracting 1 from both for loops (from the width and height).

I ran 4 trials on this program:

tic-tac-toe.txt: the given file for the lab. Contains valid formed pieces.
tic-tac-toe2.txt: has weird pieces with incorrect values but passes test because has at least one well formed piece.
tic-tac-toe3.txt: is all gibberish, no well formed pieces
tic-tac-toe4.pptx: a powerpoint presentation, cannot open file.

H:\332-AGAIN\Labs\Lab2.2\x64\Debug>lab2.2.exe tic-tac-toe.txt
XXO
OX
XOO

H:\332-AGAIN\Labs\Lab2.2\x64\Debug>echo %errorlevel%
0

H:\332-AGAIN\Labs\Lab2.2\x64\Debug>lab2.2.exe tic-tac-toe3.txt
Not a well formed piece

H:\332-AGAIN\Labs\Lab2.2\x64\Debug>echo %errorlevel%
11

H:\332-AGAIN\Labs\Lab2.2\x64\Debug>lab2.2.exe tic-tac-toe4.pptx
Could not extract from file

H:\332-AGAIN\Labs\Lab2.2\x64\Debug>echo %errorlevel%
10