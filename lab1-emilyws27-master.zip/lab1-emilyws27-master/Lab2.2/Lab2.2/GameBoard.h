/*
Header.h
Emily Sheehan, e.sheehan@wustl.edu

GameBoard.h contains the function definitions for the three constructors in the GameBoard.cpp file
*/
#pragma once

#include "GamePieces.h"
#include "Header.h"
#include <sstream>
#include <fstream>
#include <vector>

using namespace std;

int get_board_dimensions(ifstream& f, unsigned int& r, unsigned int& c);
int read_in_game_piece(ifstream& f, vector<game_piece>& v, unsigned int w, unsigned int h);
int print_game_board_pieces(const vector<game_piece>& v, unsigned int w, unsigned int h);