/*
Header.h
Emily Sheehan, e.sheehan@wustl.edu

Header.h contains the ArrayIndices and SuccessValues enums. It also has the function definitions for the two functions in the Lab2.cpp file
*/
#pragma once

#include <iostream>
#include <vector>
#include <string>

using namespace std;


enum ArrayIndices { //what the indexes in the argv[] mean
	PROGRAMNAME = 0,
	INPUTFILENAME = 1,
	EXPECTEDARGS = 2,
};

enum SuccessValues { //error codes
	SUCCESS = 0,
	WRONG_ARGS = 1,
	STREAM_ERROR = 2,
	GET_LINE_ERROR = 3,
	EXTRACTION_FAIL_X = 4,
	EXTRACTION_FAIL_Y = 5,
	INVALID_PIECE_COLOR = 6,
	COORDINATE_ERROR = 7,
	BOARD_DIMENSION_ERROR = 8,
	NO_DIMENSIONS = 9,
	GENERAL_EXTRACTION_ERROR = 10,
	POORLY_FORMED = 11
};

string to_lowercase(string& upper);
int usage_message(char* program, string file_name);

