/*
GameBoard.cpp
Emily Sheehan, e.sheehan@wustl.edu

Lab1.cpp contains the definitions for three functions: get_board_dimensions, read_in_game_pieces, print_game_board_pieces.
These are the main "worker functions" and help create a game board, game pieces, and the display.
*/
#include "GameBoard.h"
#include "Header.h"
#include "GamePieces.h"

#include <string>
#include <iostream>
#include <sstream>
#include <fstream>
using namespace std;

int get_board_dimensions(ifstream& fileReader, unsigned int& x, unsigned int& y) {
	/*
	* gets the dimensions of the "game board" from the txt file
	*
	* Parameters-
	* ifstream& fileReader: reference to the file stream that deals w/ and reads file
	* unsigned int& x: reference to width of board
	* unsigned int& y: reference to height of board
	*
	* Returns-
	* SuccessValue: whetehr the program ran as intended
	*/
	string z;

	if (getline(fileReader, z)) {
		istringstream strstrm(z);

		if (strstrm >> x) {
			if (strstrm >> y) {
				return SUCCESS;
			}
			return EXTRACTION_FAIL_Y;
		}

		return EXTRACTION_FAIL_X;

	}
	return GET_LINE_ERROR;

}

int read_in_game_piece(ifstream& streem, vector<game_piece>& pieces, unsigned int width, unsigned int height) {
	/*
	* reads in the game pieces from the main function and sets their values
	*
	* Parameters-
	* ifstream& streem: reference to the file stream that deals w/ and reads file
	* vector<game_piece>& pieces: the list of objects of type game_piece
	* unsigned int& width: reference to width of board
	* unsigned int& height: reference to height of board
	*
	* Returns-
	* SuccessValue: whetehr the program ran as intended
	*/
	string input;
	string color;
	string name;
	string display;

	unsigned int x;
	unsigned int y;

	bool well_formed = false;

	if (streem.is_open()) {
		while (getline(streem, input)) {
			istringstream i(input);

			bool clr = (bool)(i >> color);
			bool nme = (bool)(i >> name);
			bool dis = (bool)(i >> display);
			bool wd = (bool)(i >> x);
			bool he = (bool)(i >> y);
			bool siz = x <= width && y <= height;
			bool is_valid_clr = string_to_piece_color(color) != INVALID_COLOR;
			
			if (x <= width - 1 && y <= height - 1) {
				if (clr && nme && dis && wd && he && siz && is_valid_clr) { //if the game piece has a valid color, name, display
					piece_color col = string_to_piece_color(color);
					int coord = width * y + x;
					pieces[coord] = game_piece(col, name, display);
					well_formed = true;
				}
				
			}
		
		}

	}
	if (!well_formed) {
		return POORLY_FORMED;
	}
	return SUCCESS;

}



int print_game_board_pieces(const vector<game_piece>& board, unsigned int width, unsigned int y) {
	/*
	* displays board w/ pieces to console
	*
	* Parameters-
	* const vector<game_piece> board: list of pieces that represent the game board
	* unsigned int& width: reference to width of board
	* unsigned int& y: reference to height of board
	*
	* Returns-
	* SuccessValue: whetehr the program ran as intended
	*/
	if (board.size() != width*y) {
		return BOARD_DIMENSION_ERROR;
	}
	
		for (int row = int(y - 1); row >= 0; --row) {
			for (int col = 0; col <= width-1; ++col) {
					cout << board[int(width) * int(row) + int(col)].display; 
				}
			cout << endl;
			}
		
		return SUCCESS;
	
}