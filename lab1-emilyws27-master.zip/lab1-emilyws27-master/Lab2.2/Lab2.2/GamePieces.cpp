/*
GamePieces.cpp
Emily Sheehan, e.sheehan@wustl.edu

GamePieces.cpp contains the definitions for two functionsr: color_to_lower and string_to_piece_color, and the game piece constructor.
These convert the piece_color to/from an enum to a string .
*/

#include "GameBoard.h"
#include "Header.h"
#include "GamePieces.h"

game_piece::game_piece(piece_color c, string n, string d) { //game_pieces constructor, defined in GamePieces.h

	color_ = c;
	name = n;
	display = d;
}

string color_to_lower(piece_color color) {
	/*
	* turns enum to lowercase string
	*
	* Parameters-
	* piece_color: color enum 
	*
	* Returns-
	* string: the string version of the enum
	*/
	if (color == piece_color::RED) {
		return "red";
	}
	else if (color == piece_color::BLACK) {
		return "black";
	}
	else if (color == piece_color::WHITE) {
		return "white";
	}
	else if (color == piece_color::BLUE) {
		return "white";
	}
	else if (color == piece_color::NO_COLOR) {
		return "no_color";
	}
	else{
		return "invalid_color";
	}
}
piece_color string_to_piece_color(string color) {
	/*
	* does the opposite of the above function, converting the string of the color to the enum
	*
	* Parameters-
	* string color
	*
	* Returns-
	* the piece_color enum version of the string
	*/
	if (color == "red") {
		return piece_color::RED;
	}
	else if (color == "black") {
		return piece_color::BLACK;
	}
	else if (color == "white") {
		return piece_color::WHITE;
	}
	else if (color == "blue") {
		return piece_color::BLUE;
	}
	else if (color == "\n" | color == " " | color == "no_color" | color == "\t3") {
		return piece_color::NO_COLOR;
	}
	else {
		return piece_color::INVALID_COLOR;
	}
}