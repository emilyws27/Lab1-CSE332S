/*
GamePieces.h
Emily Sheehan, e.sheehan@wustl.edu

contains the piece_color enum and the game_piece struct as well as the constructors for the functions in GamePieces.cpp
*/
#pragma once
#include <string>

using namespace std;

enum piece_color { //which refers to the possible colors for a game piece
	RED = 0,
	BLACK = 1,
	WHITE = 2,
	BLUE =5,
	NO_COLOR = 3,
	INVALID_COLOR = 4,
};

struct game_piece {	//consists of a color, name, and display type
	game_piece(piece_color c, string n, string d);

	piece_color color_;
	string name;
	string display;

};

string color_to_lower(piece_color p);
piece_color string_to_piece_color(string s);

//#endif /* GAMEPIECES_H */