/*
Lab2.cpp
Emily Sheehan, e.sheehan@wustl.edu

Lab1.cpp contains the definitions for three functions: parse_file, usage_message, and main.
The file executes the project's intended purpose: reading in text from a file, parsing it and creating game piece objs, and displaying them to the console.
*/

#include "Header.h"
#include "GameBoard.h"
#include "GamePieces.h"


#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>


using namespace std;


string to_lowercase(string& upper) {
    /*
    * converts string to all lowercase
    *
    * Parameters-
    * string upper: the color that needs to be converted to lowercase
    *
    * Returns-
    * placeholder: string that is all lowercase
    */
    string placeholder = upper;
    int index = 0;
    while (placeholder[index] != '\0') {
        if (placeholder[index] >= 'A' && placeholder[index] <= 'Z') {
            placeholder[index] += 32;   //+32 to convert from uppercase to lowercase
        }
        ++index;
    }
    return placeholder;
}

int usage_message(char* name, string argument_format) {
    /*
    * displays a message summarizing how to run the program
    *
    * Parameters-
    * char* name: c-style string that refers to the name of the program (argv[0])
    * string argument_format: what the command line args should look like
    *
    * Returns-
    * WRONG_ARGS: if wrong num of args given in command line
    */

    cout << "This program, " << name << ", reads in lines from a file that represent pawns/pieces in a game. It then creates" <<
        " pieces objects, ensures their validity, and displays the game board with the pieces. To run the program, you must have two command line aruments."<<
        " the name of the program and the file from which you will read from such as, " << argument_format << " .Here's an example: Lab2.2.exe tic-tac-toe.txt" << endl;
    return WRONG_ARGS;
}
int main(int argc, char* argv[])
{
    /*
    * responsible for starting the execution and termination of this program. Calls the functions in GameBoard.cpp
    that read in and display the lines from the file. 
    *
    * Parameters-
    * int argc: number of parameters given in command line
    * char* argv[]: array of arguments
    *
    * Returns-
    * SuccessValue: either 0 or 1 depending on whether program operates correctly.
    */

    if (argc != EXPECTEDARGS)                                                                           //wrong num of args given in command line
    {
        char* program = argv[PROGRAMNAME];
        string expected_arguments = "program name, input file name";
        return usage_message(program, expected_arguments);
    }
    else {

        unsigned int horizontal;
        unsigned int vertical;
        int row = NO_DIMENSIONS;

        ifstream fileStream;

        string file_name = argv[INPUTFILENAME];
        fileStream.open(file_name);
        if (fileStream.is_open()) {
            while (row == NO_DIMENSIONS) {
                row = get_board_dimensions(fileStream, horizontal, vertical);
                if (row == GET_LINE_ERROR) {
                    cout << "Could not extract from file" << endl;
                    return GENERAL_EXTRACTION_ERROR;
                }
                if (row != NO_DIMENSIONS) {
                    break;
                }
            }
            vector<game_piece> pieces;
            for (unsigned int i = 0; i < horizontal * vertical; i++) {
                game_piece empty = game_piece(NO_COLOR, " ", " "); //temporary game piece to be populated by function

                pieces.push_back(empty);
            }
            int read = read_in_game_piece(fileStream, pieces, horizontal, vertical); 

            if (read == SUCCESS) {
                int print = print_game_board_pieces(pieces, horizontal, vertical);
                return print;

                
            }
            else {
                cout << "Not a well formed piece" << endl;
                return POORLY_FORMED;
                
            }

        }
        else {
            cout << "could not open file" << endl;
            return STREAM_ERROR;
        }
    }
    return SUCCESS;

}