#include <GamePieces.h>
#include <GameBoard.h>

string color_to_lower(piece_color color) {
	if (color == RED) {
		return "red";
	}
	else if (color == BLACK) {
		return "black";
	}
	else if (color == WHITE) {
		return "white";
	}
	else if (color == INVALID_COLOR) {
		return "invalid_color";
	}
	else if (color == NO_COLOR) {
		return "no_color";
	}
}
piece_color string_to_piece_color(string color) {
	if (color == "red") {
		return piece_color::RED;
	}
	else if (color == "black") {
		return piece_color::BLACK;
	}
	else if (color == "white") {
		return piece_color::WHITE;
	}
	
	else if (color == "\n" | color == " " | color == "no_color" | color == "\t3") {
		return piece_color::NO_COLOR;
	}
	else{
		return piece_color::INVALID_COLOR;
	}
}