#ifndef GAMEPIECES_H
#define GAMEPIECES_H

#include <string>

enum piece_color {
	RED,
	BLACK,
	WHITE,
	NO_COLOR,
	INVALID_COLOR,
};

string color_to_lower(piece_color);
piece_color string_to_piece_color(string);

struct game_piece {
	game_piece(piece_color color, string piece_name, string how_to_display);
	piece_color color_;
	string piece_name_;
	string how_to_display_;
};