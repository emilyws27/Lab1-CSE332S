#include <GamePieces.h>
#include <Header.h>
#include <sstream>
#include <iostream>

using namespace std;

int get_board_dimensions(ifstream&, unsigned int&, unsigned int&);

