/*
Lab1.cpp
Emily Sheehan, e.sheehan@wustl.edu

Lab1.cpp contains the definitions for three functions: parse_file, usage_message, and main.
The file executes the project's intended purpose: reading in text from a file, interpreting whether it is a string or numerical value, and then displaying the file's identified strings and then integers.
*/

#include "Header.h"

#include <iostream>
#include <ifstream>
#include <sstream>
#include <string>
#include <cctype>
#include <algorithm>
#include <string>
#include <GameBoard.h>
#include <GameBoard.cpp>
#include <GamePieces.cpp>
#include <GamePieces.h>

using namespace std;

ifstream fileStream;

void to_lowercase(string& upper) {
    std::transform(upper.begin(), upper.end(), upper.begin(), ::tolower);
}

int usage_message(char* name, string argument_format) {
    /*
    * displays a message summarizing how to run the program
    *
    * Parameters-
    * char* name: c-style string that refers to the name of the program (argv[0])
    *
    * Returns-
    * WRONG_ARGS: if wrong num of args given in command line
    */

    cout << "This program, " << name << ", reads in the contents of a file, for example test1.txt, and parses it into strings and integers. It first identifies strings that consist" <<
        "of integers only and adds them to a vector of integers. Then, it prints all of the non - integer strings line-by-line, and then prints out the converted integers. A command line example" <<
        "would be: Lab1.cpp ../text1.txt" << endl;
    return WRONG_ARGS;
}
int main(int argc, char* argv[])
{
    /*
    * responsible for starting the execution and termination of this program. Displays results of parse_file line by line to console.
    *
    * Parameters-
    * int argc: number of parameters given in command line
    * char* argv[]: array of arguments
    *
    * Returns-
    * SuccessValue: either 0 or 1 depending on whether program operates correctly.
    */

    if (argc != EXPECTEDARGS)                                                                           //wrong num of args given in command line
    {
        char* program = argv[PROGRAMNAME];
        string expected_arguments = "program name, input file name"
        return usage_message(program, expected_arguments);
    }
    else {

        unsigned int horizontal;
        unsigned int vertical;
        int row = NO_DIMENSIONS;

        string file_name = argv[1];
        fileStream.open(file_name);
        if (fileStream.is_open()) {
            while (row == NO_DIMENSIONS) {
                row = get_board_dimensions(fileStream, horizontal, vertical);
                if (row == GET_LINE_ERROR) {
                    cout << "Could not extract from file" << endl;
                    return GENERAL_EXTRACTION_ERROR;
                }
                if (row != NO_DIMENSIONS) {
                    break;
                }
            }
            vector<game_piece> pieces;
            game_piece empty = game_piece(" ", " ", NO_COLOR);
            for (unsigned int i = 0; i < horizontal * vertical; i++) {
                pieces.push_back(empty);
            }
            int read = read_in_game_pieces(fileStream, pieces, horizontal, vertical);
            if (read != SUCCESS) {
                cout << "An error was found when trying to read in the pieces" << endl;
                return read;
            }
            else {
                int print = print_game_board_pieces(pieces, horizontal, vertical);
                return print;
            }

        }

    }

   
}