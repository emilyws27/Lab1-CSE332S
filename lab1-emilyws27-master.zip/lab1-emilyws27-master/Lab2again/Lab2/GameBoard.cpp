#include <GameBoard.h>
#include <string>
#include <iostream>
#include <sstream>
#include <Header.h>
#include <GamePieces.h>
#include <GameBoard.h>

using namespace std;

int get_board_dimensions(ifstream& input_file_stream, unsigned int& x, unsigned int& y) {
	
	string empty;

	if (getline(input_file_stream, empty)) {
		istringstream strstrm(empty);

		if (strstrm >> x) {
			if (strstrm >> y) {
				return SUCCESS;
			}
			return EXTRACTION_FAIL_Y;
		}
	
		return EXTRACTION_FAIL_X;
	
	}
	return GET_LINE_ERROR;

}

int int read_in_game_piece(ifstream&streem, vector<game_piece>& pieces, unsigned int width, unsigned int height) {
	string start;

	if (streem.is_open()) {
		while (getline(streem, start)) {
			string piece1_color;
			string piece_name;
			string piece_printed;

			unsigned int x_;
			unsigned int y_;

			if (streem >> piece1_color >> piece_name >> piece_printed >> x_ >> y_) {
				piece_color pce_clr = string_to_piece_color(piece1_color);
				if (pce_clr != piece_color::INVALID_COLOR) {
					if (x_ < width && y_ < height) {
						// game piece definition considered well formed 
						int loc = width * y_ + x_
						game_piece gp = game_piece(piece_name, pce_clr, piece_printed);
						pieced[index] = gp;
						return SUCCESS;
					}
					return COORDINATE_ERROR;
				}
				return INVALID_PIECE_COLOR;
			}
			return WRONG_ARGS;
		}
	}
	streem.close();
	return STREAM_ERROR;
}

int print_game_board_pieces(const vector<game_piece>& board, unsigned int width, unsigned int y) {
	//(0,0) = lower left-hand corner
	//(1,1) = upper right-hand corner

	int size = width * height;
	if (board.size() != size) {
		return BOARD_DIMENSION_ERROR;
	}
	else {
		for (unsigned int row = height - 1; row >= 0; --row) {
			for (unsigned int col = 0; column <= width - 1; ++column) {
				if (column == width - 1) {
					cout << board[width * row + col].how_to_display_ << endl;

				}
				else{
					cout << display[width * row + col].how_to_display_;
					return BOARD_DIMENSION_ERROR;
				}
			}
		}
		return SUCCESS;
	}
}