Emily Sheehan, WUSTL ID: 490280
Lab3

This is a Tic-Tac-Toe game that allows two people to successfully play tic-tac-toe with X's and O's. 

Errors that I encountered:
I did not include my Header in tic-tac-toe.h and vice versa, which created a conflict.
I also initially did not have a return for every scenario for each function in the TTT.cpp, so I was getting the location in memory vs the actual  return values
My board is a little off by one space in the x value, I tried to fix it but don't have enough time... It still prints and functions fine but the x and y coordinate is shifted one to the left when printed.
Potential Error values:

	SUCCESS = 0,
	WRONG_ARGS = 1,
	QUIT_GAME = 2,
	DRAW_GAME = 3,
	CANT_READ_STRING = 4,				//if istringstream cant read in
	VALUE_OUT_OF_RANGE = 5,
	NOT_A_COMMA = 6,					//if val at first index is not comma
	NOT_AN_EMPTY_SPACE_IN_BOARD = 7,	// if space already taken
	OTHER = 8,
____________________________________________________________________________________________________
Testing a "draw":
1,3

4
3YXX
2XYY
1YXX
0
 01234
Number of Spaces Remaining: -1
The game ends in a tie/draw with 10 number of moves between X and O
____________________________________________________________________________________________________
Testing a "win":

Please enter a valid coordinate (ex. '0,0'), or type 'quit' if you would like to exit the game.
1,3

0
4
3
2  XX
1 YYY
0
 01234
Number of Spaces Remaining: 4
Player Y won the game. Congrats!
____________________________________________________________________________________________________
Testing the quit function:

H:\332-AGAIN\Labs\Lab3.2\x64\Debug>Lab3.2.exe TicTacToe
4
3
2
1
0
 01234

Next Turn: Player Y
Please enter a valid coordinate (ex. '0,0'), or type 'quit' if you would like to exit the game.
quit

2
Player Y quit the game. Goodbye!
____________________________________________________________________________________________________
Tested when only 1 argument is given in the command line (calls usage_message()):

H:\332-AGAIN\Labs\Lab3.2\x64\Debug>Lab3.2.exe
This program, Lab3.2.exe, reads in lines from a file that represent pawns/pieces in a game. 
It then creates pieces objects, ensures their validity, and displays the game board with the pieces. 
To run the program, you must have two command line aruments. The name of the program and the file from which you will read from such as,
program name, TicTacToe .Here's an example: Lab2.2.exe tic-tac-toe.txt

____________________________________________________________________________________________________
Tested when only 1 argument is given as the coord:

H:\332-AGAIN\Labs\Lab3.2\x64\Debug>Lab3.2.exe TicTacToe
Please enter a valid coordinate (ex. '0,0'), or type 'quit' if you would like to exit the game.
4
3
2
1
0
 01234

Next Turn: Player Y
afds

ERROR CODE: 1
INVALID INPUT: the input should be in the format 'x,y'. The char at position 0 and 2 must be a digit 1-3; the char at pos 1 must be a comma